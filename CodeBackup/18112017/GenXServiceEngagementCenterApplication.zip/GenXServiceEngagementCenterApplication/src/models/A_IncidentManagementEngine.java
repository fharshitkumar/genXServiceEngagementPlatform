package models;

public class A_IncidentManagementEngine {

	public A_IncidentManagementEngine() {
		super();

	}

}
